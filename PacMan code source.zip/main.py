import view

if __name__ == '__main__':
    game = view.View()
    game.mainLoop()




